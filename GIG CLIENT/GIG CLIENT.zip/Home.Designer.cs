﻿namespace GIG_CLIENT
{
    partial class Home
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Home));
            this.metroStatusBar1 = new DevComponents.DotNetBar.Metro.MetroStatusBar();
            this.slb = new DevComponents.DotNetBar.LabelItem();
            this.conlb = new DevComponents.DotNetBar.LabelItem();
            this.metroShell1 = new DevComponents.DotNetBar.Metro.MetroShell();
            this.buttonItem1 = new DevComponents.DotNetBar.ButtonItem();
            this.addserverbtn = new DevComponents.DotNetBar.ButtonItem();
            this.findfriendbtn = new DevComponents.DotNetBar.ButtonItem();
            this.sendmsgbtn = new DevComponents.DotNetBar.ButtonItem();
            this.notifybtn = new DevComponents.DotNetBar.ButtonItem();
            this.showtrans = new DevComponents.DotNetBar.ButtonItem();
            this.setrolectrl = new DevComponents.DotNetBar.ButtonItem();
            this.showall = new DevComponents.DotNetBar.ButtonItem();
            this.prodmgr = new DevComponents.DotNetBar.ButtonItem();
            this.buttonItem3 = new DevComponents.DotNetBar.ButtonItem();
            this.buttonItem4 = new DevComponents.DotNetBar.ButtonItem();
            this.UpdateNewsbtn = new DevComponents.DotNetBar.ButtonItem();
            this.aboutbtn = new DevComponents.DotNetBar.ButtonItem();
            this.disconbtn = new DevComponents.DotNetBar.ButtonItem();
            this.styleManager1 = new DevComponents.DotNetBar.StyleManager(this.components);
            this.notifyIcon1 = new System.Windows.Forms.NotifyIcon(this.components);
            this.contextMenuBar1 = new DevComponents.DotNetBar.ContextMenuBar();
            this.bEditPopup = new DevComponents.DotNetBar.ButtonItem();
            this.avuibtn = new DevComponents.DotNetBar.ButtonItem();
            this.buttonItem2 = new DevComponents.DotNetBar.ButtonItem();
            this.bSelectAll = new DevComponents.DotNetBar.ButtonItem();
            ((System.ComponentModel.ISupportInitialize)(this.contextMenuBar1)).BeginInit();
            this.SuspendLayout();
            // 
            // metroStatusBar1
            // 
            this.metroStatusBar1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(62)))), ((int)(((byte)(67)))));
            // 
            // 
            // 
            this.metroStatusBar1.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.metroStatusBar1.ContainerControlProcessDialogKey = true;
            this.metroStatusBar1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.metroStatusBar1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F, System.Drawing.FontStyle.Bold);
            this.metroStatusBar1.ForeColor = System.Drawing.Color.White;
            this.metroStatusBar1.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.slb,
            this.conlb});
            this.metroStatusBar1.Location = new System.Drawing.Point(1, 498);
            this.metroStatusBar1.Name = "metroStatusBar1";
            this.metroStatusBar1.ResizeHandleVisible = false;
            this.metroStatusBar1.Size = new System.Drawing.Size(829, 26);
            this.metroStatusBar1.TabIndex = 2;
            this.metroStatusBar1.Text = "metroStatusBar1";
            // 
            // slb
            // 
            this.slb.Name = "slb";
            this.slb.Stretch = true;
            this.slb.Text = "Prêt";
            // 
            // conlb
            // 
            this.conlb.Name = "conlb";
            this.conlb.Text = "CON";
            // 
            // metroShell1
            // 
            this.metroShell1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(62)))), ((int)(((byte)(67)))));
            // 
            // 
            // 
            this.metroShell1.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.metroShell1.CaptionVisible = true;
            this.metroShell1.Dock = System.Windows.Forms.DockStyle.Top;
            this.metroShell1.ForeColor = System.Drawing.Color.White;
            this.metroShell1.HelpButtonText = "Paramètres";
            this.metroShell1.KeyTipsFont = new System.Drawing.Font("Tahoma", 7F);
            this.metroShell1.Location = new System.Drawing.Point(1, 1);
            this.metroShell1.Name = "metroShell1";
            this.metroShell1.QuickToolbarItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.buttonItem1});
            this.metroShell1.SettingsButtonText = "Retour";
            this.metroShell1.Size = new System.Drawing.Size(829, 33);
            this.metroShell1.SystemText.MaximizeRibbonText = "&Maximize the Ribbon";
            this.metroShell1.SystemText.MinimizeRibbonText = "Mi&nimize the Ribbon";
            this.metroShell1.SystemText.QatAddItemText = "&Add to Quick Access Toolbar";
            this.metroShell1.SystemText.QatCustomizeMenuLabel = "<b>Customize Quick Access Toolbar</b>";
            this.metroShell1.SystemText.QatCustomizeText = "&Customize Quick Access Toolbar...";
            this.metroShell1.SystemText.QatDialogAddButton = "&Add >>";
            this.metroShell1.SystemText.QatDialogCancelButton = "Cancel";
            this.metroShell1.SystemText.QatDialogCaption = "Customize Quick Access Toolbar";
            this.metroShell1.SystemText.QatDialogCategoriesLabel = "&Choose commands from:";
            this.metroShell1.SystemText.QatDialogOkButton = "OK";
            this.metroShell1.SystemText.QatDialogPlacementCheckbox = "&Place Quick Access Toolbar below the Ribbon";
            this.metroShell1.SystemText.QatDialogRemoveButton = "&Remove";
            this.metroShell1.SystemText.QatPlaceAboveRibbonText = "&Place Quick Access Toolbar above the Ribbon";
            this.metroShell1.SystemText.QatPlaceBelowRibbonText = "&Place Quick Access Toolbar below the Ribbon";
            this.metroShell1.SystemText.QatRemoveItemText = "&Remove from Quick Access Toolbar";
            this.metroShell1.TabIndex = 3;
            this.metroShell1.TabStripFont = new System.Drawing.Font("Microsoft Sans Serif", 10.25F, System.Drawing.FontStyle.Bold);
            this.metroShell1.Text = "metroShell1";
            this.metroShell1.SettingsButtonClick += new System.EventHandler(this.metroShell1_SettingsButtonClick);
            this.metroShell1.HelpButtonClick += new System.EventHandler(this.metroShell1_HelpButtonClick);
            // 
            // buttonItem1
            // 
            this.buttonItem1.Image = global::GIG_CLIENT.Properties.Resources.user;
            this.buttonItem1.ImageFixedSize = new System.Drawing.Size(20, 20);
            this.buttonItem1.Name = "buttonItem1";
            this.buttonItem1.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.addserverbtn,
            this.findfriendbtn,
            this.sendmsgbtn,
            this.notifybtn,
            this.showtrans,
            this.setrolectrl,
            this.showall,
            this.prodmgr,
            this.UpdateNewsbtn,
            this.aboutbtn,
            this.disconbtn});
            this.buttonItem1.Text = "Mon Compte";
            this.buttonItem1.EnabledChanged += new System.EventHandler(this.buttonItem1_EnabledChanged);
            // 
            // addserverbtn
            // 
            this.addserverbtn.Name = "addserverbtn";
            this.addserverbtn.Text = "Ajouter un serveur";
            this.addserverbtn.Visible = false;
            this.addserverbtn.Click += new System.EventHandler(this.addserverbtn_Click);
            // 
            // findfriendbtn
            // 
            this.findfriendbtn.Name = "findfriendbtn";
            this.findfriendbtn.Text = "Trouver un utilisateur";
            this.findfriendbtn.Click += new System.EventHandler(this.findfriendbtn_Click);
            // 
            // sendmsgbtn
            // 
            this.sendmsgbtn.Name = "sendmsgbtn";
            this.sendmsgbtn.Text = "Envoyer un message";
            this.sendmsgbtn.Click += new System.EventHandler(this.sendmsgbtn_Click);
            // 
            // notifybtn
            // 
            this.notifybtn.Name = "notifybtn";
            this.notifybtn.Text = "Notifier un utilisateur";
            this.notifybtn.Visible = false;
            this.notifybtn.Click += new System.EventHandler(this.notifybtn_Click);
            // 
            // showtrans
            // 
            this.showtrans.Name = "showtrans";
            this.showtrans.Text = "Afficher les transactions";
            this.showtrans.Visible = false;
            this.showtrans.Click += new System.EventHandler(this.showtrans_Click);
            // 
            // setrolectrl
            // 
            this.setrolectrl.Name = "setrolectrl";
            this.setrolectrl.Text = "Modifier le Role";
            this.setrolectrl.Visible = false;
            this.setrolectrl.Click += new System.EventHandler(this.setrolectrl_Click);
            // 
            // showall
            // 
            this.showall.Name = "showall";
            this.showall.Text = "Afficher les utilisateur";
            this.showall.Visible = false;
            this.showall.Click += new System.EventHandler(this.showall_Click);
            // 
            // prodmgr
            // 
            this.prodmgr.Name = "prodmgr";
            this.prodmgr.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.buttonItem3,
            this.buttonItem4});
            this.prodmgr.Text = "Produits";
            this.prodmgr.Visible = false;
            // 
            // buttonItem3
            // 
            this.buttonItem3.Name = "buttonItem3";
            this.buttonItem3.Text = "Ajouter un produit";
            this.buttonItem3.Click += new System.EventHandler(this.buttonItem3_Click);
            // 
            // buttonItem4
            // 
            this.buttonItem4.Name = "buttonItem4";
            this.buttonItem4.Text = "Supprimer un produit";
            this.buttonItem4.Click += new System.EventHandler(this.buttonItem4_Click);
            // 
            // UpdateNewsbtn
            // 
            this.UpdateNewsbtn.Name = "UpdateNewsbtn";
            this.UpdateNewsbtn.Text = "Ajouter une actualité";
            this.UpdateNewsbtn.Visible = false;
            this.UpdateNewsbtn.Click += new System.EventHandler(this.UpdateNewsbtn_Click);
            // 
            // aboutbtn
            // 
            this.aboutbtn.Name = "aboutbtn";
            this.aboutbtn.Text = "À Propos";
            this.aboutbtn.Click += new System.EventHandler(this.aboutbtn_Click);
            // 
            // disconbtn
            // 
            this.disconbtn.Name = "disconbtn";
            this.disconbtn.Text = "Déconnecter";
            this.disconbtn.Click += new System.EventHandler(this.disconbtn_Click);
            // 
            // styleManager1
            // 
            this.styleManager1.ManagerStyle = DevComponents.DotNetBar.eStyle.Metro;
            this.styleManager1.MetroColorParameters = new DevComponents.DotNetBar.Metro.ColorTables.MetroColorGeneratorParameters(System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(62)))), ((int)(((byte)(67))))), System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(120)))), ((int)(((byte)(143))))));
            // 
            // notifyIcon1
            // 
            this.notifyIcon1.Icon = ((System.Drawing.Icon)(resources.GetObject("notifyIcon1.Icon")));
            this.notifyIcon1.Text = "Greed In Games Client";
            this.notifyIcon1.Visible = true;
            this.notifyIcon1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.notifyIcon1_MouseClick);
            this.notifyIcon1.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.notifyIcon1_MouseDoubleClick);
            // 
            // contextMenuBar1
            // 
            this.contextMenuBar1.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.contextMenuBar1.ForeColor = System.Drawing.Color.White;
            this.contextMenuBar1.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.bEditPopup});
            this.contextMenuBar1.Location = new System.Drawing.Point(311, 220);
            this.contextMenuBar1.Name = "contextMenuBar1";
            this.contextMenuBar1.Size = new System.Drawing.Size(150, 25);
            this.contextMenuBar1.Stretch = true;
            this.contextMenuBar1.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.contextMenuBar1.TabIndex = 17;
            this.contextMenuBar1.TabStop = false;
            // 
            // bEditPopup
            // 
            this.bEditPopup.AutoExpandOnClick = true;
            this.bEditPopup.GlobalName = "bEditPopup";
            this.bEditPopup.Name = "bEditPopup";
            this.bEditPopup.PopupAnimation = DevComponents.DotNetBar.ePopupAnimation.SystemDefault;
            this.bEditPopup.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.avuibtn,
            this.buttonItem2,
            this.bSelectAll});
            this.bEditPopup.Text = "bEditPopup";
            // 
            // avuibtn
            // 
            this.avuibtn.Name = "avuibtn";
            this.avuibtn.Text = "Afficher l\'interface GIG";
            this.avuibtn.Click += new System.EventHandler(this.avuibtn_Click);
            // 
            // buttonItem2
            // 
            this.buttonItem2.Name = "buttonItem2";
            this.buttonItem2.Text = "À Propos";
            this.buttonItem2.Click += new System.EventHandler(this.aboutbtn_Click);
            // 
            // bSelectAll
            // 
            this.bSelectAll.BeginGroup = true;
            this.bSelectAll.GlobalName = "bSelectAll";
            this.bSelectAll.Name = "bSelectAll";
            this.bSelectAll.PopupAnimation = DevComponents.DotNetBar.ePopupAnimation.SystemDefault;
            this.bSelectAll.Text = "Quitter";
            this.bSelectAll.Click += new System.EventHandler(this.quitterToolStripMenuItem_Click);
            // 
            // Home
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(62)))), ((int)(((byte)(67)))));
            this.ClientSize = new System.Drawing.Size(831, 525);
            this.Controls.Add(this.contextMenuBar1);
            this.Controls.Add(this.metroShell1);
            this.Controls.Add(this.metroStatusBar1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.ForeColor = System.Drawing.Color.White;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.ModalPanelBoundsExcludeStatusBar = true;
            this.Name = "Home";
            this.Text = "Greed In Games ";
            this.Load += new System.EventHandler(this.Home_Load);
            this.Shown += new System.EventHandler(this.Home_Shown);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Home_FormClosing);
            this.Resize += new System.EventHandler(this.Home_Resize);
            ((System.ComponentModel.ISupportInitialize)(this.contextMenuBar1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        internal DevComponents.DotNetBar.Metro.MetroStatusBar metroStatusBar1;
        internal DevComponents.DotNetBar.LabelItem conlb;
        private DevComponents.DotNetBar.Metro.MetroShell metroShell1;
        private DevComponents.DotNetBar.StyleManager styleManager1;
        private DevComponents.DotNetBar.ButtonItem addserverbtn;
        private DevComponents.DotNetBar.ButtonItem findfriendbtn;
        private DevComponents.DotNetBar.ButtonItem sendmsgbtn;
        private DevComponents.DotNetBar.ButtonItem notifybtn;
        private DevComponents.DotNetBar.ButtonItem showtrans;
        private DevComponents.DotNetBar.ButtonItem UpdateNewsbtn;
        private DevComponents.DotNetBar.ButtonItem disconbtn;
        internal DevComponents.DotNetBar.LabelItem slb;
        internal System.Windows.Forms.NotifyIcon notifyIcon1;
        private DevComponents.DotNetBar.ButtonItem aboutbtn;
        internal DevComponents.DotNetBar.ButtonItem buttonItem1;
        private DevComponents.DotNetBar.ContextMenuBar contextMenuBar1;
        internal DevComponents.DotNetBar.ButtonItem bEditPopup;
        internal DevComponents.DotNetBar.ButtonItem avuibtn;
        internal DevComponents.DotNetBar.ButtonItem buttonItem2;
        internal DevComponents.DotNetBar.ButtonItem bSelectAll;
        private DevComponents.DotNetBar.ButtonItem setrolectrl;
        private DevComponents.DotNetBar.ButtonItem showall;
        private DevComponents.DotNetBar.ButtonItem prodmgr;
        private DevComponents.DotNetBar.ButtonItem buttonItem3;
        private DevComponents.DotNetBar.ButtonItem buttonItem4;
    }
}