using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DevComponents.DotNetBar;
using System.Net;

namespace GIG_CLIENT
{
    public partial class AddServerFrm : DevComponents.DotNetBar.Metro.MetroForm
    {
        public AddServerFrm()
        {
            InitializeComponent();
        }

        private void buttonX2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void buttonX1_Click(object sender, EventArgs e)
        {
            try
            {
                if (textBoxX1.Text.Length > 0)
                    GigSpace.Client.AddServer(textBoxX1.Text, new IPEndPoint(IPAddress.Parse(ipAddressInput1.Value), integerInput1.Value));

                this.Close();
            }
            catch (Exception ex)
            {
                GigSpace.LogError(ex);
            }
        }
    }
}