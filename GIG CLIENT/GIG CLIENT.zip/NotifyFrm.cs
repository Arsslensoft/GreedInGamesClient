using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DevComponents.DotNetBar;

namespace GIG_CLIENT
{
    public partial class NotifyFrm : DevComponents.DotNetBar.Metro.MetroForm
    {
        public NotifyFrm()
        {
            InitializeComponent();
        }

        private void buttonX2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void buttonX1_Click(object sender, EventArgs e)
        {
            try
            {
                if (textBoxX1.Text.Length > 0 && textBoxX2.Text.Length > 0)
                    if (GigSpace.Client.Notify(textBoxX1.Text, textBoxX2.Text))
                        MessageBoxEx.Show("Utilisateur notifi� avec succ�s", "Notify", MessageBoxButtons.OK, MessageBoxIcon.Information);

                this.Close();
            }
            catch
            {

            }
        }
    }
}