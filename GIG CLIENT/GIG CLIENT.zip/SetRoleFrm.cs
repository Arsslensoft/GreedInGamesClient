﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DevComponents.DotNetBar.Metro;
using GIG.Client;
using DevComponents.DotNetBar;
namespace GIG_CLIENT
{
    public partial class SetRoleFrm : MetroForm
    {
        public SetRoleFrm()
        {
            InitializeComponent();
        }

        private void buttonX1_Click(object sender, EventArgs e)
        {
            try
            {
                if (textBoxX1.Text.Length > 0 && comboBoxEx1.Text.Length > 0)
                {
                    GIGRoles role = GIGRoles.Utilisateur;
                    if (comboBoxEx1.Text == "Directeur")
                        role = GIGRoles.Directeur;
                    else  if (comboBoxEx1.Text == "Administrateur")
                        role = GIGRoles.Administrateur;
                    else  if (comboBoxEx1.Text == "Moderateur")
                        role = GIGRoles.Moderateur;

                    if (GigSpace.Client.SetUserRole(textBoxX1.Text, (byte)role))
                        MessageBoxEx.Show("Role changé avec succès","Role", MessageBoxButtons.OK, MessageBoxIcon.Information);
               
                }
                this.Close();
            }
            catch
            {

            }
        }
    }
}
