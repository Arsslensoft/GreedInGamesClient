using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DevComponents.DotNetBar;

namespace GIG_CLIENT
{
    public partial class Form4 : DevComponents.DotNetBar.Metro.MetroForm
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void buttonX1_Click(object sender, EventArgs e)
        {
            try
            {
                int d = 0;
                bool k = int.TryParse(textBoxX1.Text, out d);
                if (d > 0 && k)
                {
                   if(GigSpace.Client.RemoveProduct(textBoxX1.Text))
                       MessageBoxEx.Show("Produit supprim� avec succ�s", " Gestionnaire des Produits", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                this.Close();
            }
            catch
            {

            }
        }
    }
}