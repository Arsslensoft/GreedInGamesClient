﻿namespace GIG_CLIENT
{
    partial class ProfileCtrl
    {
        /// <summary> 
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur de composants

        /// <summary> 
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas 
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.superTabControl1 = new DevComponents.DotNetBar.SuperTabControl();
            this.superTabControlPanel4 = new DevComponents.DotNetBar.SuperTabControlPanel();
            this.calendarView1 = new DevComponents.DotNetBar.Schedule.CalendarView();
            this.dateNavigator1 = new DevComponents.DotNetBar.Schedule.DateNavigator();
            this.barView = new DevComponents.DotNetBar.Bar();
            this.btnDay = new DevComponents.DotNetBar.ButtonItem();
            this.btnWeek = new DevComponents.DotNetBar.ButtonItem();
            this.btnMonth = new DevComponents.DotNetBar.ButtonItem();
            this.btnYear = new DevComponents.DotNetBar.ButtonItem();
            this.btnTimeLine = new DevComponents.DotNetBar.ButtonItem();
            this.buttonItem1 = new DevComponents.DotNetBar.ButtonItem();
            this.buttonItem2 = new DevComponents.DotNetBar.ButtonItem();
            this.buttonItem3 = new DevComponents.DotNetBar.ButtonItem();
            this.superTabItem3 = new DevComponents.DotNetBar.SuperTabItem();
            this.superTabControlPanel1 = new DevComponents.DotNetBar.SuperTabControlPanel();
            this.dlb = new DevComponents.DotNetBar.LabelX();
            this.rlb = new DevComponents.DotNetBar.LabelX();
            this.elb = new DevComponents.DotNetBar.LabelX();
            this.nlb = new DevComponents.DotNetBar.LabelX();
            this.unlb = new DevComponents.DotNetBar.LabelX();
            this.labelX10 = new DevComponents.DotNetBar.LabelX();
            this.labelX5 = new DevComponents.DotNetBar.LabelX();
            this.flist = new DevComponents.DotNetBar.ItemPanel();
            this.labelX4 = new DevComponents.DotNetBar.LabelX();
            this.labelX3 = new DevComponents.DotNetBar.LabelX();
            this.labelX2 = new DevComponents.DotNetBar.LabelX();
            this.labelX1 = new DevComponents.DotNetBar.LabelX();
            this.superTabItem1 = new DevComponents.DotNetBar.SuperTabItem();
            this.superTabControlPanel3 = new DevComponents.DotNetBar.SuperTabControlPanel();
            this.buttonX1 = new DevComponents.DotNetBar.ButtonX();
            this.nlist = new DevComponents.DotNetBar.ItemPanel();
            this.labelX11 = new DevComponents.DotNetBar.LabelX();
            this.Notificationtab = new DevComponents.DotNetBar.SuperTabItem();
            this.superTabControlPanel2 = new DevComponents.DotNetBar.SuperTabControlPanel();
            this.gigplb = new DevComponents.DotNetBar.LabelX();
            this.vipgta = new DevComponents.DotNetBar.LabelX();
            this.gtaunlb = new DevComponents.DotNetBar.LabelX();
            this.labelX9 = new DevComponents.DotNetBar.LabelX();
            this.vlist = new DevComponents.DotNetBar.ItemPanel();
            this.labelX8 = new DevComponents.DotNetBar.LabelX();
            this.labelX7 = new DevComponents.DotNetBar.LabelX();
            this.labelX6 = new DevComponents.DotNetBar.LabelX();
            this.superTabItem2 = new DevComponents.DotNetBar.SuperTabItem();
            this.buttonItem4 = new DevComponents.DotNetBar.ButtonItem();
            ((System.ComponentModel.ISupportInitialize)(this.superTabControl1)).BeginInit();
            this.superTabControl1.SuspendLayout();
            this.superTabControlPanel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.barView)).BeginInit();
            this.superTabControlPanel1.SuspendLayout();
            this.superTabControlPanel3.SuspendLayout();
            this.superTabControlPanel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // superTabControl1
            // 
            this.superTabControl1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(62)))), ((int)(((byte)(67)))));
            // 
            // 
            // 
            // 
            // 
            // 
            this.superTabControl1.ControlBox.CloseBox.Name = "";
            // 
            // 
            // 
            this.superTabControl1.ControlBox.MenuBox.Name = "";
            this.superTabControl1.ControlBox.Name = "";
            this.superTabControl1.ControlBox.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.superTabControl1.ControlBox.MenuBox,
            this.superTabControl1.ControlBox.CloseBox});
            this.superTabControl1.Controls.Add(this.superTabControlPanel4);
            this.superTabControl1.Controls.Add(this.superTabControlPanel1);
            this.superTabControl1.Controls.Add(this.superTabControlPanel3);
            this.superTabControl1.Controls.Add(this.superTabControlPanel2);
            this.superTabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.superTabControl1.ForeColor = System.Drawing.Color.White;
            this.superTabControl1.Location = new System.Drawing.Point(0, 0);
            this.superTabControl1.Name = "superTabControl1";
            this.superTabControl1.ReorderTabsEnabled = true;
            this.superTabControl1.SelectedTabFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.superTabControl1.SelectedTabIndex = 1;
            this.superTabControl1.Size = new System.Drawing.Size(808, 406);
            this.superTabControl1.TabFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.superTabControl1.TabIndex = 0;
            this.superTabControl1.Tabs.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.superTabItem1,
            this.superTabItem2,
            this.Notificationtab,
            this.superTabItem3,
            this.buttonItem4});
            this.superTabControl1.TabStyle = DevComponents.DotNetBar.eSuperTabStyle.Office2010BackstageBlue;
            this.superTabControl1.Text = "superTabControl1";
            // 
            // superTabControlPanel4
            // 
            this.superTabControlPanel4.Controls.Add(this.calendarView1);
            this.superTabControlPanel4.Controls.Add(this.dateNavigator1);
            this.superTabControlPanel4.Controls.Add(this.barView);
            this.superTabControlPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.superTabControlPanel4.Location = new System.Drawing.Point(0, 24);
            this.superTabControlPanel4.Name = "superTabControlPanel4";
            this.superTabControlPanel4.Size = new System.Drawing.Size(808, 382);
            this.superTabControlPanel4.TabIndex = 0;
            this.superTabControlPanel4.TabItem = this.superTabItem3;
            // 
            // calendarView1
            // 
            this.calendarView1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(62)))), ((int)(((byte)(63)))));
            // 
            // 
            // 
            this.calendarView1.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.calendarView1.ContainerControlProcessDialogKey = true;
            this.calendarView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.calendarView1.ForeColor = System.Drawing.Color.White;
            this.calendarView1.HighlightCurrentDay = true;
            this.calendarView1.Is24HourFormat = true;
            this.calendarView1.LabelTimeSlots = true;
            this.calendarView1.Location = new System.Drawing.Point(0, 56);
            this.calendarView1.MultiUserTabHeight = 19;
            this.calendarView1.Name = "calendarView1";
            this.calendarView1.Size = new System.Drawing.Size(808, 326);
            this.calendarView1.TabIndex = 8;
            this.calendarView1.Text = "calendarView1";
            this.calendarView1.TimeIndicator.BorderColor = System.Drawing.Color.Empty;
            this.calendarView1.TimeIndicator.IndicatorArea = DevComponents.DotNetBar.Schedule.eTimeIndicatorArea.All;
            this.calendarView1.TimeIndicator.Tag = null;
            this.calendarView1.TimeIndicator.Visibility = DevComponents.DotNetBar.Schedule.eTimeIndicatorVisibility.AllResources;
            this.calendarView1.TimeSlotDuration = 15;
            // 
            // dateNavigator1
            // 
            this.dateNavigator1.CalendarView = this.calendarView1;
            this.dateNavigator1.CanvasColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(62)))), ((int)(((byte)(63)))));
            this.dateNavigator1.Dock = System.Windows.Forms.DockStyle.Top;
            this.dateNavigator1.Location = new System.Drawing.Point(0, 26);
            this.dateNavigator1.Name = "dateNavigator1";
            this.dateNavigator1.Size = new System.Drawing.Size(808, 30);
            this.dateNavigator1.Style.BackColor1.Color = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(241)))), ((int)(((byte)(242)))));
            this.dateNavigator1.TabIndex = 7;
            this.dateNavigator1.Text = "dateNavigator1";
            // 
            // barView
            // 
            this.barView.Dock = System.Windows.Forms.DockStyle.Top;
            this.barView.DockSide = DevComponents.DotNetBar.eDockSide.Document;
            this.barView.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.barView.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.btnDay,
            this.btnWeek,
            this.btnMonth,
            this.btnYear,
            this.btnTimeLine,
            this.buttonItem1,
            this.buttonItem2,
            this.buttonItem3});
            this.barView.Location = new System.Drawing.Point(0, 0);
            this.barView.Name = "barView";
            this.barView.RoundCorners = false;
            this.barView.Size = new System.Drawing.Size(808, 26);
            this.barView.Stretch = true;
            this.barView.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.barView.TabIndex = 6;
            this.barView.TabStop = false;
            this.barView.Text = "bar1";
            // 
            // btnDay
            // 
            this.btnDay.Checked = true;
            this.btnDay.Name = "btnDay";
            this.btnDay.OptionGroup = "View";
            this.btnDay.Text = "Jour";
            this.btnDay.Click += new System.EventHandler(this.btnDay_Click);
            // 
            // btnWeek
            // 
            this.btnWeek.Name = "btnWeek";
            this.btnWeek.OptionGroup = "View";
            this.btnWeek.Text = "Semaine";
            this.btnWeek.Click += new System.EventHandler(this.btnWeek_Click);
            // 
            // btnMonth
            // 
            this.btnMonth.Name = "btnMonth";
            this.btnMonth.OptionGroup = "View";
            this.btnMonth.Text = "Mois";
            this.btnMonth.Click += new System.EventHandler(this.btnMonth_Click);
            // 
            // btnYear
            // 
            this.btnYear.Name = "btnYear";
            this.btnYear.OptionGroup = "View";
            this.btnYear.Text = "Année";
            this.btnYear.Click += new System.EventHandler(this.btnYear_Click);
            // 
            // btnTimeLine
            // 
            this.btnTimeLine.Name = "btnTimeLine";
            this.btnTimeLine.OptionGroup = "View";
            this.btnTimeLine.Text = "Chronologie";
            this.btnTimeLine.Click += new System.EventHandler(this.btnTimeLine_Click);
            // 
            // buttonItem1
            // 
            this.buttonItem1.Name = "buttonItem1";
            this.buttonItem1.Text = "Ajouter un rendez-vous";
            this.buttonItem1.Click += new System.EventHandler(this.buttonItem1_Click);
            // 
            // buttonItem2
            // 
            this.buttonItem2.Name = "buttonItem2";
            this.buttonItem2.Text = "Supprimer un rendez-vous";
            this.buttonItem2.Click += new System.EventHandler(this.buttonItem2_Click);
            // 
            // buttonItem3
            // 
            this.buttonItem3.Name = "buttonItem3";
            this.buttonItem3.Text = "Enregistrer";
            this.buttonItem3.Click += new System.EventHandler(this.buttonItem3_Click);
            // 
            // superTabItem3
            // 
            this.superTabItem3.AttachedControl = this.superTabControlPanel4;
            this.superTabItem3.GlobalItem = false;
            this.superTabItem3.Name = "superTabItem3";
            this.superTabItem3.Text = "Mon Calendrier";
            this.superTabItem3.Visible = false;
            // 
            // superTabControlPanel1
            // 
            this.superTabControlPanel1.Controls.Add(this.dlb);
            this.superTabControlPanel1.Controls.Add(this.rlb);
            this.superTabControlPanel1.Controls.Add(this.elb);
            this.superTabControlPanel1.Controls.Add(this.nlb);
            this.superTabControlPanel1.Controls.Add(this.unlb);
            this.superTabControlPanel1.Controls.Add(this.labelX10);
            this.superTabControlPanel1.Controls.Add(this.labelX5);
            this.superTabControlPanel1.Controls.Add(this.flist);
            this.superTabControlPanel1.Controls.Add(this.labelX4);
            this.superTabControlPanel1.Controls.Add(this.labelX3);
            this.superTabControlPanel1.Controls.Add(this.labelX2);
            this.superTabControlPanel1.Controls.Add(this.labelX1);
            this.superTabControlPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.superTabControlPanel1.Location = new System.Drawing.Point(0, 24);
            this.superTabControlPanel1.Name = "superTabControlPanel1";
            this.superTabControlPanel1.Size = new System.Drawing.Size(808, 382);
            this.superTabControlPanel1.TabIndex = 1;
            this.superTabControlPanel1.TabItem = this.superTabItem1;
            // 
            // dlb
            // 
            this.dlb.BackColor = System.Drawing.Color.Transparent;
            // 
            // 
            // 
            this.dlb.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.dlb.Location = new System.Drawing.Point(154, 147);
            this.dlb.Name = "dlb";
            this.dlb.Size = new System.Drawing.Size(225, 23);
            this.dlb.TabIndex = 11;
            // 
            // rlb
            // 
            this.rlb.BackColor = System.Drawing.Color.Transparent;
            // 
            // 
            // 
            this.rlb.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.rlb.Location = new System.Drawing.Point(154, 118);
            this.rlb.Name = "rlb";
            this.rlb.Size = new System.Drawing.Size(225, 23);
            this.rlb.TabIndex = 10;
            // 
            // elb
            // 
            this.elb.BackColor = System.Drawing.Color.Transparent;
            // 
            // 
            // 
            this.elb.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.elb.Location = new System.Drawing.Point(154, 89);
            this.elb.Name = "elb";
            this.elb.Size = new System.Drawing.Size(225, 23);
            this.elb.TabIndex = 9;
            // 
            // nlb
            // 
            this.nlb.BackColor = System.Drawing.Color.Transparent;
            // 
            // 
            // 
            this.nlb.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.nlb.Location = new System.Drawing.Point(154, 60);
            this.nlb.Name = "nlb";
            this.nlb.Size = new System.Drawing.Size(225, 23);
            this.nlb.TabIndex = 8;
            // 
            // unlb
            // 
            this.unlb.BackColor = System.Drawing.Color.Transparent;
            // 
            // 
            // 
            this.unlb.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.unlb.Location = new System.Drawing.Point(154, 31);
            this.unlb.Name = "unlb";
            this.unlb.Size = new System.Drawing.Size(225, 23);
            this.unlb.TabIndex = 7;
            // 
            // labelX10
            // 
            this.labelX10.BackColor = System.Drawing.Color.Transparent;
            // 
            // 
            // 
            this.labelX10.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX10.Location = new System.Drawing.Point(21, 147);
            this.labelX10.Name = "labelX10";
            this.labelX10.Size = new System.Drawing.Size(225, 23);
            this.labelX10.TabIndex = 6;
            this.labelX10.Text = "Date d\'enregistrement   :";
            // 
            // labelX5
            // 
            this.labelX5.BackColor = System.Drawing.Color.Transparent;
            // 
            // 
            // 
            this.labelX5.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX5.Location = new System.Drawing.Point(21, 181);
            this.labelX5.Name = "labelX5";
            this.labelX5.Size = new System.Drawing.Size(200, 23);
            this.labelX5.TabIndex = 5;
            this.labelX5.Text = "Liste d\'amis";
            // 
            // flist
            // 
            this.flist.AutoScroll = true;
            // 
            // 
            // 
            this.flist.BackgroundStyle.Class = "ItemPanel";
            this.flist.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.flist.ContainerControlProcessDialogKey = true;
            this.flist.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.flist.LayoutOrientation = DevComponents.DotNetBar.eOrientation.Vertical;
            this.flist.Location = new System.Drawing.Point(0, 209);
            this.flist.Name = "flist";
            this.flist.ScrollBarAppearance = DevComponents.DotNetBar.eScrollBarAppearance.ApplicationScroll;
            this.flist.Size = new System.Drawing.Size(808, 173);
            this.flist.TabIndex = 4;
            this.flist.Text = "flist";
            // 
            // labelX4
            // 
            this.labelX4.BackColor = System.Drawing.Color.Transparent;
            // 
            // 
            // 
            this.labelX4.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX4.Location = new System.Drawing.Point(21, 118);
            this.labelX4.Name = "labelX4";
            this.labelX4.Size = new System.Drawing.Size(225, 23);
            this.labelX4.TabIndex = 3;
            this.labelX4.Text = "Rôle                                :";
            // 
            // labelX3
            // 
            this.labelX3.BackColor = System.Drawing.Color.Transparent;
            // 
            // 
            // 
            this.labelX3.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX3.Location = new System.Drawing.Point(21, 89);
            this.labelX3.Name = "labelX3";
            this.labelX3.Size = new System.Drawing.Size(225, 23);
            this.labelX3.TabIndex = 2;
            this.labelX3.Text = "Adresse email                :";
            // 
            // labelX2
            // 
            this.labelX2.BackColor = System.Drawing.Color.Transparent;
            // 
            // 
            // 
            this.labelX2.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX2.Location = new System.Drawing.Point(21, 60);
            this.labelX2.Name = "labelX2";
            this.labelX2.Size = new System.Drawing.Size(225, 23);
            this.labelX2.TabIndex = 1;
            this.labelX2.Text = "Nom                                :";
            // 
            // labelX1
            // 
            this.labelX1.BackColor = System.Drawing.Color.Transparent;
            // 
            // 
            // 
            this.labelX1.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX1.Location = new System.Drawing.Point(21, 31);
            this.labelX1.Name = "labelX1";
            this.labelX1.Size = new System.Drawing.Size(225, 23);
            this.labelX1.TabIndex = 0;
            this.labelX1.Text = "Nom d\'utilisateur            :";
            // 
            // superTabItem1
            // 
            this.superTabItem1.AttachedControl = this.superTabControlPanel1;
            this.superTabItem1.GlobalItem = false;
            this.superTabItem1.Name = "superTabItem1";
            this.superTabItem1.Text = "Informations de base";
            // 
            // superTabControlPanel3
            // 
            this.superTabControlPanel3.Controls.Add(this.buttonX1);
            this.superTabControlPanel3.Controls.Add(this.nlist);
            this.superTabControlPanel3.Controls.Add(this.labelX11);
            this.superTabControlPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.superTabControlPanel3.Location = new System.Drawing.Point(0, 0);
            this.superTabControlPanel3.Name = "superTabControlPanel3";
            this.superTabControlPanel3.Size = new System.Drawing.Size(808, 406);
            this.superTabControlPanel3.TabIndex = 0;
            this.superTabControlPanel3.TabItem = this.Notificationtab;
            // 
            // buttonX1
            // 
            this.buttonX1.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.buttonX1.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.buttonX1.Location = new System.Drawing.Point(506, 6);
            this.buttonX1.Name = "buttonX1";
            this.buttonX1.Size = new System.Drawing.Size(75, 23);
            this.buttonX1.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.buttonX1.TabIndex = 2;
            this.buttonX1.Text = "Vider";
            this.buttonX1.Click += new System.EventHandler(this.buttonX1_Click);
            // 
            // nlist
            // 
            this.nlist.AutoScroll = true;
            this.nlist.BackColor = System.Drawing.Color.Transparent;
            // 
            // 
            // 
            this.nlist.BackgroundStyle.Class = "ItemPanel";
            this.nlist.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.nlist.ContainerControlProcessDialogKey = true;
            this.nlist.Dock = System.Windows.Forms.DockStyle.Fill;
            this.nlist.LayoutOrientation = DevComponents.DotNetBar.eOrientation.Vertical;
            this.nlist.Location = new System.Drawing.Point(0, 33);
            this.nlist.Name = "nlist";
            this.nlist.ScrollBarAppearance = DevComponents.DotNetBar.eScrollBarAppearance.ApplicationScroll;
            this.nlist.Size = new System.Drawing.Size(808, 373);
            this.nlist.TabIndex = 1;
            this.nlist.Text = "itemPanel1";
            // 
            // labelX11
            // 
            this.labelX11.BackColor = System.Drawing.Color.Transparent;
            // 
            // 
            // 
            this.labelX11.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX11.Dock = System.Windows.Forms.DockStyle.Top;
            this.labelX11.Location = new System.Drawing.Point(0, 0);
            this.labelX11.Name = "labelX11";
            this.labelX11.Size = new System.Drawing.Size(808, 33);
            this.labelX11.TabIndex = 0;
            this.labelX11.Text = "Notifications";
            // 
            // Notificationtab
            // 
            this.Notificationtab.AttachedControl = this.superTabControlPanel3;
            this.Notificationtab.GlobalItem = false;
            this.Notificationtab.Name = "Notificationtab";
            this.Notificationtab.Text = "Notifications";
            this.Notificationtab.Visible = false;
            // 
            // superTabControlPanel2
            // 
            this.superTabControlPanel2.Controls.Add(this.gigplb);
            this.superTabControlPanel2.Controls.Add(this.vipgta);
            this.superTabControlPanel2.Controls.Add(this.gtaunlb);
            this.superTabControlPanel2.Controls.Add(this.labelX9);
            this.superTabControlPanel2.Controls.Add(this.vlist);
            this.superTabControlPanel2.Controls.Add(this.labelX8);
            this.superTabControlPanel2.Controls.Add(this.labelX7);
            this.superTabControlPanel2.Controls.Add(this.labelX6);
            this.superTabControlPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.superTabControlPanel2.Location = new System.Drawing.Point(0, 0);
            this.superTabControlPanel2.Name = "superTabControlPanel2";
            this.superTabControlPanel2.Size = new System.Drawing.Size(808, 406);
            this.superTabControlPanel2.TabIndex = 0;
            this.superTabControlPanel2.TabItem = this.superTabItem2;
            // 
            // gigplb
            // 
            this.gigplb.BackColor = System.Drawing.Color.Transparent;
            // 
            // 
            // 
            this.gigplb.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.gigplb.Location = new System.Drawing.Point(151, 108);
            this.gigplb.Name = "gigplb";
            this.gigplb.Size = new System.Drawing.Size(225, 23);
            this.gigplb.TabIndex = 12;
            // 
            // vipgta
            // 
            this.vipgta.BackColor = System.Drawing.Color.Transparent;
            // 
            // 
            // 
            this.vipgta.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.vipgta.Location = new System.Drawing.Point(151, 68);
            this.vipgta.Name = "vipgta";
            this.vipgta.Size = new System.Drawing.Size(225, 23);
            this.vipgta.TabIndex = 11;
            // 
            // gtaunlb
            // 
            this.gtaunlb.BackColor = System.Drawing.Color.Transparent;
            // 
            // 
            // 
            this.gtaunlb.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.gtaunlb.Location = new System.Drawing.Point(151, 30);
            this.gtaunlb.Name = "gtaunlb";
            this.gtaunlb.Size = new System.Drawing.Size(225, 23);
            this.gtaunlb.TabIndex = 10;
            // 
            // labelX9
            // 
            this.labelX9.BackColor = System.Drawing.Color.Transparent;
            // 
            // 
            // 
            this.labelX9.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX9.Location = new System.Drawing.Point(20, 152);
            this.labelX9.Name = "labelX9";
            this.labelX9.Size = new System.Drawing.Size(225, 23);
            this.labelX9.TabIndex = 5;
            this.labelX9.Text = "Liste des véhicules";
            // 
            // vlist
            // 
            this.vlist.AutoScroll = true;
            // 
            // 
            // 
            this.vlist.BackgroundStyle.Class = "ItemPanel";
            this.vlist.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.vlist.ContainerControlProcessDialogKey = true;
            this.vlist.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.vlist.LayoutOrientation = DevComponents.DotNetBar.eOrientation.Vertical;
            this.vlist.Location = new System.Drawing.Point(0, 206);
            this.vlist.Name = "vlist";
            this.vlist.ScrollBarAppearance = DevComponents.DotNetBar.eScrollBarAppearance.ApplicationScroll;
            this.vlist.Size = new System.Drawing.Size(808, 200);
            this.vlist.TabIndex = 4;
            this.vlist.Text = "vehl";
            // 
            // labelX8
            // 
            this.labelX8.BackColor = System.Drawing.Color.Transparent;
            // 
            // 
            // 
            this.labelX8.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX8.Location = new System.Drawing.Point(20, 108);
            this.labelX8.Name = "labelX8";
            this.labelX8.Size = new System.Drawing.Size(225, 23);
            this.labelX8.TabIndex = 3;
            this.labelX8.Text = "Solde Points GIG         :";
            // 
            // labelX7
            // 
            this.labelX7.BackColor = System.Drawing.Color.Transparent;
            // 
            // 
            // 
            this.labelX7.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX7.Location = new System.Drawing.Point(20, 68);
            this.labelX7.Name = "labelX7";
            this.labelX7.Size = new System.Drawing.Size(225, 23);
            this.labelX7.TabIndex = 2;
            this.labelX7.Text = "Utilisateur GTA VIP      :";
            // 
            // labelX6
            // 
            this.labelX6.BackColor = System.Drawing.Color.Transparent;
            // 
            // 
            // 
            this.labelX6.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX6.Location = new System.Drawing.Point(20, 30);
            this.labelX6.Name = "labelX6";
            this.labelX6.Size = new System.Drawing.Size(225, 23);
            this.labelX6.TabIndex = 1;
            this.labelX6.Text = "Nom d\'utilisateur GTA  :";
            // 
            // superTabItem2
            // 
            this.superTabItem2.AttachedControl = this.superTabControlPanel2;
            this.superTabItem2.GlobalItem = false;
            this.superTabItem2.Name = "superTabItem2";
            this.superTabItem2.Text = "Informations OGRP";
            // 
            // buttonItem4
            // 
            this.buttonItem4.Name = "buttonItem4";
            this.buttonItem4.Text = "Annuler l\'amitié";
            this.buttonItem4.Visible = false;
            this.buttonItem4.Click += new System.EventHandler(this.buttonItem4_Click);
            // 
            // ProfileCtrl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(62)))), ((int)(((byte)(67)))));
            this.Controls.Add(this.superTabControl1);
            this.Name = "ProfileCtrl";
            this.Size = new System.Drawing.Size(808, 406);
            ((System.ComponentModel.ISupportInitialize)(this.superTabControl1)).EndInit();
            this.superTabControl1.ResumeLayout(false);
            this.superTabControlPanel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.barView)).EndInit();
            this.superTabControlPanel1.ResumeLayout(false);
            this.superTabControlPanel3.ResumeLayout(false);
            this.superTabControlPanel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private DevComponents.DotNetBar.SuperTabControl superTabControl1;
        private DevComponents.DotNetBar.SuperTabControlPanel superTabControlPanel2;
        private DevComponents.DotNetBar.SuperTabItem superTabItem2;
        private DevComponents.DotNetBar.SuperTabControlPanel superTabControlPanel1;
        private DevComponents.DotNetBar.SuperTabItem superTabItem1;
        private DevComponents.DotNetBar.LabelX labelX4;
        private DevComponents.DotNetBar.LabelX labelX3;
        private DevComponents.DotNetBar.LabelX labelX2;
        private DevComponents.DotNetBar.LabelX labelX1;
        private DevComponents.DotNetBar.LabelX labelX5;
        private DevComponents.DotNetBar.ItemPanel flist;
        private DevComponents.DotNetBar.LabelX labelX6;
        private DevComponents.DotNetBar.LabelX labelX8;
        private DevComponents.DotNetBar.LabelX labelX7;
        private DevComponents.DotNetBar.LabelX labelX9;
        private DevComponents.DotNetBar.ItemPanel vlist;
        private DevComponents.DotNetBar.LabelX labelX10;
        private DevComponents.DotNetBar.LabelX dlb;
        private DevComponents.DotNetBar.LabelX rlb;
        private DevComponents.DotNetBar.LabelX elb;
        private DevComponents.DotNetBar.LabelX nlb;
        private DevComponents.DotNetBar.LabelX unlb;
        private DevComponents.DotNetBar.LabelX gigplb;
        private DevComponents.DotNetBar.LabelX vipgta;
        private DevComponents.DotNetBar.LabelX gtaunlb;
        private DevComponents.DotNetBar.SuperTabControlPanel superTabControlPanel3;
        private DevComponents.DotNetBar.SuperTabItem Notificationtab;
        private DevComponents.DotNetBar.LabelX labelX11;
        private DevComponents.DotNetBar.ItemPanel nlist;
        private DevComponents.DotNetBar.SuperTabControlPanel superTabControlPanel4;
        private DevComponents.DotNetBar.SuperTabItem superTabItem3;
        private DevComponents.DotNetBar.Schedule.CalendarView calendarView1;
        private DevComponents.DotNetBar.Schedule.DateNavigator dateNavigator1;
        private DevComponents.DotNetBar.Bar barView;
        private DevComponents.DotNetBar.ButtonItem btnDay;
        private DevComponents.DotNetBar.ButtonItem btnWeek;
        private DevComponents.DotNetBar.ButtonItem btnMonth;
        private DevComponents.DotNetBar.ButtonItem btnYear;
        private DevComponents.DotNetBar.ButtonItem btnTimeLine;
        private DevComponents.DotNetBar.ButtonItem buttonItem1;
        private DevComponents.DotNetBar.ButtonItem buttonItem2;
        private DevComponents.DotNetBar.ButtonItem buttonItem3;
        private DevComponents.DotNetBar.ButtonX buttonX1;
        private DevComponents.DotNetBar.ButtonItem buttonItem4;
    }
}
