using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DevComponents.DotNetBar;
using System.Net;
using System.Xml;
using System.IO;

namespace GIG_CLIENT
{
    public partial class Form2 : DevComponents.DotNetBar.Metro.MetroForm
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void buttonX1_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrEmpty(textBoxX1.Text) || string.IsNullOrEmpty(textBoxX2.Text) || (textBoxX1.Text + textBoxX2.Text).Contains("&") || (textBoxX1.Text + textBoxX2.Text).Contains("=") || (textBoxX1.Text + textBoxX2.Text).Contains(".") || (textBoxX1.Text + textBoxX2.Text).Contains("?"))
                    MessageBoxEx.Show("Enterer un message et un nom d'utilisateur valides", "Actualit�", MessageBoxButtons.OK, MessageBoxIcon.Information);
                else
                {
                    WebClient cl = new WebClient();
                    cl.DownloadFile(GigSpace.HOST + "/News.xml", Application.StartupPath + @"\Data\News.xml");
                    XmlDocument doc = new XmlDocument();
                    doc.Load(Application.StartupPath + @"\Data\News.xml");
                    if (doc.ChildNodes.Count > 30)
                        doc.DocumentElement.RemoveChild(doc.ChildNodes[doc.ChildNodes.Count - 1]);

                    XmlElement el = doc.CreateElement("item");
                    XmlAttribute name = doc.CreateAttribute("name");
                    name.Value = textBoxX1.Text;
                    el.Attributes.Append(name);
                    el.InnerText = textBoxX2.Text;
                    doc.DocumentElement.InsertBefore(el, doc.DocumentElement.ChildNodes[0]);

                    doc.Save(Application.StartupPath + @"\Data\News.xml");

                    if (!File.Exists(Application.StartupPath + @"\Data\FTP.dat"))
                    {
                        FtpLoginfrm frm = new FtpLoginfrm();
                        frm.ShowDialog();
                        if (frm.Done)
                        {
                            ftp f = new ftp(frm.textBoxX1.Text, frm.textBoxX2.Text, frm.textBoxX3.Text);
                            File.WriteAllLines(Application.StartupPath + @"\Data\FTP.dat", new string[3] { frm.textBoxX1.Text, frm.textBoxX2.Text, frm.textBoxX3.Text});
                            f.delete("News.xml");
                            f.upload("News.xml", Application.StartupPath + @"\Data\News.xml");
                            this.Close();
                        }
                        else
                            this.Close();
                    }
                    else
                    {
                        string[] ln = File.ReadAllLines(Application.StartupPath + @"\Data\FTP.dat");
                        ftp f = new ftp(ln[0], ln[1], ln[2]);

                        f.delete("News.xml");
                        f.upload("News.xml", Application.StartupPath + @"\Data\News.xml");
                        this.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                GigSpace.LogError(ex);
            }
            finally
            {
                this.Close();
            }
        }
    }
}