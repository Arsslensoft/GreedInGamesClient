﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using GIG.Client;
using DevComponents.DotNetBar;

namespace GIG_CLIENT
{
    public partial class AllUsersCtrl : UserControl
    {
        public AllUsersCtrl()
        {
            InitializeComponent();
        }
        public void Init()
        {
            try
            {
             
                    GigSpace.SetSTAT("Recherche des utilisateurs...");
                    List<string> u = GigSpace.Client.GetAllUsers(integerInput1.Value);
                    itemPanel1.Items.Clear();
                    GigSpace.SetSTAT(u.Count.ToString() + " utilisateur(s) trouvé(s)");
                    foreach (string user in u)
                    {
                        ButtonItem item = new ButtonItem();
                        item.Image = GIG_CLIENT.Properties.Resources.user;
                        item.Text = user;
                        item.Name = user;
                        item.ButtonStyle = eButtonStyle.ImageAndText;
                        item.Click += new EventHandler(item_Click);
                        itemPanel1.Items.Add(item);
                    }

                    this.Refresh();
           

            }
            catch (Exception ex)
            {
                GigSpace.LogError(ex);
            }
        }

        private void item_Click(object sender, EventArgs e)
        {
            try
            {
                ButtonItem btn = (ButtonItem)sender;
                GigUser g = GigSpace.Client.GetUserInfo(btn.Text);
                GigSpace.ShowUserInfo(g);
            }
            catch (Exception ex)
            {
                GigSpace.LogError(ex);
            }
        }

        private void buttonX1_Click(object sender, EventArgs e)
        {
            Init();
        }
    }
}
